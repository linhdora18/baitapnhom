# ScentStation firmware core — slot numbering fix

## Slot-numbering contract

- Protocol/API commands use human-facing slot numbers **1 through 5**.
- Internal C++ arrays and HAL methods remain **zero-based (0 through 4)**.
- `Device::on_command()` validates the protocol slot and converts it once using `idx = c.slot - 1`.
- Internal helper APIs `Device::slot(i)` and `install_bottle(i, ...)` continue to use zero-based indexes.
- Slot `0`, negative slots, and slots above `Config::slot_count` are rejected with `BAD_SLOT`.

## Run unit tests

From this directory:

```sh
make test
```

The `trace.json` file is retained from the supplied project. Run `python3 validate_trace.py` to validate the recorded trace structure; this does not regenerate frames. See `TEST_REPORT.md` for the verification distinction.
