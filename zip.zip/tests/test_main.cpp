#include "mini_test.h"
int main() {
  int bad_tests = 0;
  for (auto& t : registry()) {
    int before = failures();
    t.fn();
    bool ok = failures() == before;
    std::printf("[%s] %s\n", ok ? " OK " : "FAIL", t.name);
    if (!ok) bad_tests++;
  }
  std::printf("\n%zu tests, %d failed, %d failed checks\n", registry().size(), bad_tests, failures());
  return bad_tests ? 1 : 0;
}
