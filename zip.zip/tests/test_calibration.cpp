#include <cmath>

#include "../core/calibration.h"
#include "mini_test.h"

using namespace ss;

TEST(load_cell_two_point_calibration) {
  LoadCellCal c;
  CHECK(calibrate_load_cell(8400, 8400 + 21500, 100000, &c));   // 100 g reference gives +21500 counts
  CHECK_EQ(c.to_mg(8400), 0);
  CHECK_EQ(c.to_mg(8400 + 21500), 100000);
  CHECK(std::abs(c.to_mg(8400 + 10750) - 50000) <= 1);
  CHECK(!calibrate_load_cell(100, 100, 5000, &c));              // no change in reading: refuse
  CHECK(!calibrate_load_cell(100, 200, 0, &c));
}

TEST(dose_curve_fit_recovers_slope_and_dead_time) {
  // true model: 0.75 mg/ms with 20 ms dead time
  DosePoint p[4] = {{60, 30}, {100, 60}, {140, 90}, {180, 120}};
  double s, o;
  CHECK(fit_dose_curve(p, 4, &s, &o));
  CHECK(std::fabs(s - 0.75) < 1e-9);
  CHECK(std::fabs(o - 20) < 1e-9);
  CHECK_EQ(dose_for_target(s, o, 90), 140u);
  CHECK_EQ(dose_for_target(s, o, 0.1), 20u);   // 0.13 ms + 20 ms dead time, rounded
  CHECK(!fit_dose_curve(p, 2, &s, &o));                          // too few points
  DosePoint flat[3] = {{60, 50}, {100, 50}, {140, 50}};
  CHECK(!fit_dose_curve(flat, 3, &s, &o));                       // no dose response: hardware problem
  DosePoint same[3] = {{100, 40}, {100, 50}, {100, 60}};
  CHECK(!fit_dose_curve(same, 3, &s, &o));
}

TEST(repeatability_cv) {
  double good[5] = {90, 91, 89, 90, 92}, bad[5] = {90, 60, 120, 85, 100};
  CHECK(coefficient_of_variation(good, 5) < 5.0);
  CHECK(coefficient_of_variation(bad, 5) > 5.0);
  CHECK(coefficient_of_variation(good, 1) >= 100.0);
}
