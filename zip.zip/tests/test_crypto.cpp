#include "../core/protocol.h"
#include "../core/sha256.h"
#include "mini_test.h"

using namespace ss;

static std::string h(const std::string& s) { uint8_t o[32]; sha256((const uint8_t*)s.data(), s.size(), o); return to_hex(o, 32); }
static std::string hm(const std::string& k, const std::string& m) { uint8_t o[32]; hmac_sha256((const uint8_t*)k.data(), k.size(), (const uint8_t*)m.data(), m.size(), o); return to_hex(o, 32); }

TEST(sha256_known_vectors) {
  CHECK_EQ(h(""), std::string("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"));
  CHECK_EQ(h("abc"), std::string("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"));
  CHECK_EQ(h("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"), std::string("248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1"));
  CHECK_EQ(h(std::string(1000, 'a')), std::string("41edece42d63e8d9bf515a9ba6932e1c20cbc9f5a5d134645adb5db1b9737ea3"));
}

TEST(hmac_rfc4231_vectors) {
  CHECK_EQ(hm(std::string(20, '\x0b'), "Hi There"), std::string("b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7"));
  CHECK_EQ(hm("Jefe", "what do ya want for nothing?"), std::string("5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843"));
  // key longer than the block size (RFC 4231 case 6)
  CHECK_EQ(hm(std::string(131, '\xaa'), "Test Using Larger Than Block-Size Key - Hash Key First"),
           std::string("60e431591ee0b67f0d8a26aacbf5b77f8e0bc6213728c5140546040f0ee37f54"));
}

TEST(signature_matches_backend_vector) {   // value produced independently with Python hmac/hashlib
  Command c; c.command_id = "cmd-0001"; c.device_id = "SS-0001"; c.slot = 2; c.action = Action::SPRAY; c.dose_ms = 120;
  c.issued_at = 1760000000; c.expires_at = 1760000030; c.order_id = "ord-42";
  std::string key = hex_decode("00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff");
  CHECK_EQ(canonical(c), std::string("v1|cmd-0001|SS-0001|2|SPRAY|120|1760000000|1760000030|ord-42"));
  CHECK_EQ(sign(key, c), std::string("a07d23e5394e18612b65062a03fe53c79146479e627266884610c87e251f3a76"));
  c.signature = sign(key, c);
  CHECK(verify_signature(key, c));
}

TEST(any_field_change_breaks_signature) {
  Command c; c.command_id = "c1"; c.device_id = "d1"; c.slot = 1; c.action = Action::SPRAY; c.dose_ms = 100; c.issued_at = 10; c.expires_at = 40; c.order_id = "o1";
  std::string key = "k";
  c.signature = sign(key, c);
  CHECK(verify_signature(key, c));
  Command t;
  t = c; t.slot = 2; CHECK(!verify_signature(key, t));
  t = c; t.dose_ms = 101; CHECK(!verify_signature(key, t));
  t = c; t.expires_at = 41; CHECK(!verify_signature(key, t));
  t = c; t.order_id = "o2"; CHECK(!verify_signature(key, t));
  t = c; t.action = Action::DIAG_SPRAY; CHECK(!verify_signature(key, t));
  t = c; t.device_id = "d2"; CHECK(!verify_signature(key, t));
  CHECK(!verify_signature("other", c));
  t = c; t.signature = "zz"; CHECK(!verify_signature(key, t));
  t = c; t.signature = std::string(64, '0'); CHECK(!verify_signature(key, t));
}

TEST(id_validation_blocks_separator_injection) {
  CHECK(valid_id("ord-42.A_b:1"));
  CHECK(!valid_id("a|b")); CHECK(!valid_id("a\nb")); CHECK(!valid_id("")); CHECK(!valid_id(std::string(65, 'a')));
}
