#include <cstdlib>
#include <memory>

#include "../core/device.h"
#include "mini_test.h"
#include "mock_hal.h"

using namespace ss;

static const std::string KEY = "0123456789abcdef0123456789abcdef";
static const char* DEV = "SS-0001";

struct Rig {
  MockHal hal;
  Config cfg;
  std::unique_ptr<Device> dev;
  int valve_on_events = 0;
  Rig() { reboot(); }
  void reboot() { hal.all_actuators_off(); dev.reset(new Device(hal, KEY, DEV, cfg)); dev->begin(); }
  Command cmd(const std::string& id, const std::string& order, int slot = 1, uint32_t dose = 120, Action a = Action::SPRAY) {
    Command c; c.command_id = id; c.device_id = DEV; c.order_id = order; c.slot = slot; c.action = a; c.dose_ms = dose;
    c.issued_at = hal.unix_s; c.expires_at = hal.unix_s + 30;
    c.signature = sign(KEY, c);
    return c;
  }
  void run(uint32_t ms) { hal.run(ms, [&] { dev->tick(); }); }
  Ack send(const Command& c) { return dev->on_command(c); }
  bool any_valve() { for (bool v : hal.valve) if (v) return true; return false; }
};

static bool is(const Ack& a, bool ok, const char* code) { return a.accepted == ok && a.code == code; }

TEST(happy_path_one_confirmed_spray) {
  Rig r;
  int32_t before = r.hal.weight[0];
  CHECK(is(r.send(r.cmd("c1", "o1")), true, "ACCEPTED"));
  CHECK(r.hal.valve[0]); CHECK(!r.hal.valve[1]); CHECK(!r.hal.valve[2]);       // only the selected slot
  CHECK_EQ(r.dev->mode(), Mode::DISPENSING);
  r.run(1000);
  CHECK(!r.any_valve());
  CHECK_EQ(r.dev->mode(), Mode::IDLE);
  auto res = r.dev->pending_results();
  CHECK_EQ(res.size(), 1u);
  CHECK(res[0].outcome == Outcome::OK);
  CHECK(res[0].delta_mg >= 80 && res[0].delta_mg <= 100);
  CHECK_EQ(res[0].order_id, std::string("o1"));
  CHECK(res[0].executed_ms >= 120 && res[0].executed_ms <= 130);
  CHECK(before - r.hal.weight[0] >= 80);
  CHECK_EQ(r.dev->slot(0).sale_sprays, 1u);
  r.dev->confirm_result("c1");
  CHECK(!r.dev->results_pending());
}


TEST(protocol_slot_five_maps_to_internal_index_four) {
  Rig r;
  CHECK(is(r.send(r.cmd("c5", "o5", 5)), true, "ACCEPTED"));
  CHECK(r.hal.valve[4]);
  CHECK(!r.hal.valve[0] && !r.hal.valve[1] && !r.hal.valve[2] && !r.hal.valve[3]);
  r.run(1000);
  CHECK(!r.any_valve());
  CHECK_EQ(r.dev->slot(4).sale_sprays, 1u);
}

TEST(every_rejection_reason_leaves_valves_closed) {
  struct Case { const char* name; const char* code; std::function<Command(Rig&)> make; };
  std::vector<Case> cases = {
    {"wrong device", "WRONG_DEVICE", [](Rig& r) { Command c = r.cmd("a", "o"); c.device_id = "SS-9999"; c.signature = sign(KEY, c); return c; }},
    {"bad signature", "BAD_SIGNATURE", [](Rig& r) { Command c = r.cmd("a", "o"); c.signature = std::string(64, 'a'); return c; }},
    {"tampered dose", "BAD_SIGNATURE", [](Rig& r) { Command c = r.cmd("a", "o"); c.dose_ms = 200; return c; }},
    {"tampered slot", "BAD_SIGNATURE", [](Rig& r) { Command c = r.cmd("a", "o"); c.slot = 2; return c; }},
    {"signed with other key", "BAD_SIGNATURE", [](Rig& r) { Command c = r.cmd("a", "o"); c.signature = sign("evil-key", c); return c; }},
    {"bad format id", "BAD_FORMAT", [](Rig& r) { Command c = r.cmd("a|b", "o"); return c; }},
    {"unknown action", "BAD_FORMAT", [](Rig& r) { Command c = r.cmd("a", "o"); c.action = Action::UNKNOWN; return c; }},
    {"expired", "EXPIRED", [](Rig& r) { Command c = r.cmd("a", "o"); c.issued_at -= 100; c.expires_at -= 100; c.signature = sign(KEY, c); return c; }},
    {"from the future", "FROM_FUTURE", [](Rig& r) { Command c = r.cmd("a", "o"); c.issued_at += 60; c.expires_at += 60; c.signature = sign(KEY, c); return c; }},
    {"window too long", "BAD_WINDOW", [](Rig& r) { Command c = r.cmd("a", "o"); c.expires_at = c.issued_at + 3600; c.signature = sign(KEY, c); return c; }},
    {"inverted window", "BAD_WINDOW", [](Rig& r) { Command c = r.cmd("a", "o"); c.expires_at = c.issued_at - 1; c.signature = sign(KEY, c); return c; }},
    {"bad slot", "BAD_SLOT", [](Rig& r) { return r.cmd("a", "o", 7); }},
    {"zero slot", "BAD_SLOT", [](Rig& r) { return r.cmd("a", "o", 0); }},
    {"negative slot", "BAD_SLOT", [](Rig& r) { return r.cmd("a", "o", -1); }},
    {"zero dose", "DOSE_OUT_OF_RANGE", [](Rig& r) { return r.cmd("a", "o", 1, 0); }},
    {"dose above hard cap", "DOSE_OUT_OF_RANGE", [](Rig& r) { return r.cmd("a", "o", 1, 5000); }},
    {"diagnostic outside maintenance", "REQUIRES_MAINTENANCE_MODE", [](Rig& r) { return r.cmd("a", "o", 1, 120, Action::DIAG_SPRAY); }},
  };
  for (auto& k : cases) {
    Rig r;
    Ack a = r.send(k.make(r));
    if (!is(a, false, k.code)) { std::printf("    case '%s': got %s\n", k.name, a.code.c_str()); CHECK(false); }
    CHECK(!r.any_valve());
    CHECK(!r.dev->results_pending());
    CHECK_EQ(r.dev->mode(), Mode::IDLE);
  }
}

TEST(state_based_rejections) {
  { Rig r; r.hal.unix_s = 0; Command c = r.cmd("a", "o"); CHECK(is(r.send(c), false, "TIME_NOT_SYNCED")); CHECK(!r.any_valve()); }
  { Rig r; r.hal.door = true; CHECK(is(r.send(r.cmd("a", "o")), false, "DOOR_OPEN")); CHECK(!r.any_valve()); }
  { Rig r; r.hal.leak = true; CHECK(is(r.send(r.cmd("a", "o")), false, "LEAK_DETECTED")); CHECK(!r.any_valve()); }
  { Rig r; r.hal.estop = true; CHECK(is(r.send(r.cmd("a", "o")), false, "ESTOP")); CHECK(!r.any_valve()); }
  { Rig r; r.hal.sensor_ok[0] = false; CHECK(is(r.send(r.cmd("a", "o")), false, "SENSOR_FAILURE")); CHECK(!r.any_valve()); }
  { Rig r; r.hal.weight[0] = 150; CHECK(is(r.send(r.cmd("a", "o")), false, "SLOT_EMPTY")); CHECK(!r.any_valve()); }
  { Rig r; r.cfg.slots[0].enabled = false; r.reboot(); CHECK(is(r.send(r.cmd("a", "o")), false, "SLOT_DISABLED")); }
  { Rig r; r.hal.storage_fails = true; CHECK(is(r.send(r.cmd("a", "o")), false, "STORAGE_FAILURE")); CHECK(!r.any_valve()); }
  { Rig r; CHECK(r.dev->enter_maintenance()); CHECK(is(r.send(r.cmd("a", "o")), false, "MAINTENANCE_MODE")); CHECK(!r.any_valve()); }
}

TEST(busy_and_cooldown) {
  Rig r;
  CHECK(is(r.send(r.cmd("c1", "o1")), true, "ACCEPTED"));
  CHECK(is(r.send(r.cmd("c2", "o2", 2)), false, "BUSY"));
  CHECK(!r.hal.valve[2]);
  r.run(900);                                                       // spray done, result recorded
  CHECK(is(r.send(r.cmd("c3", "o3", 2)), false, "COOLDOWN"));
  r.run(1600);
  CHECK(is(r.send(r.cmd("c3", "o3", 2)), true, "ACCEPTED"));
  r.run(1000);
  CHECK_EQ(r.dev->slot(1).sale_sprays, 1u);
}

TEST(replays_never_spray_twice) {
  Rig r;
  Command c = r.cmd("c1", "o1");
  CHECK(is(r.send(c), true, "ACCEPTED"));
  CHECK(is(r.send(c), false, "DUPLICATE_COMMAND"));                 // duplicate delivery while spraying
  r.run(3000);
  CHECK(is(r.send(c), false, "DUPLICATE_COMMAND"));                 // duplicate delivery after completion
  CHECK(is(r.send(r.cmd("c2", "o1")), false, "DUPLICATE_ORDER"));   // new command for the SAME paid order
  CHECK(is(r.send(r.cmd("c3", "o1", 3)), false, "DUPLICATE_ORDER"));// even for another slot
  r.run(2000);
  CHECK(!r.any_valve());
  CHECK_EQ(r.dev->slot(0).sale_sprays + r.dev->slot(2).sale_sprays, 1u);
  CHECK_EQ(r.dev->pending_results().size(), 1u);
}

TEST(randomised_replays_and_reboots_never_double_spray) {
  struct CountingHal : MockHal { int on_events = 0; void actuator(int s, bool on) override { if (on && !valve[s]) on_events++; MockHal::actuator(s, on); } };
  CountingHal hal;
  Config cfg;
  std::srand(12345);
  std::unique_ptr<Device> dev(new Device(hal, KEY, DEV, cfg));
  dev->begin();
  auto run = [&](uint32_t ms) { hal.run(ms, [&] { dev->tick(); }); };
  auto mk = [&](const std::string& id, const std::string& order, int slot) {
    Command c; c.command_id = id; c.device_id = DEV; c.order_id = order; c.slot = slot; c.action = Action::SPRAY; c.dose_ms = 120;
    c.issued_at = hal.unix_s; c.expires_at = hal.unix_s + 30; c.signature = sign(KEY, c); return c;
  };
  const int ORDERS = 10000;
  int accepted_total = 0;
  for (int i = 0; i < ORDERS; i++) {
    std::string order = "ord-" + std::to_string(i);
    int slot = (i % 4) + 1;
    hal.weight[slot - 1] = 40000;
    int accepted_for_order = 0;
    for (int attempt = 0; attempt < 4; attempt++) {                 // retries, redeliveries, new command ids for the same order
      std::string cid = (std::rand() % 2) ? "cmd-" + std::to_string(i) : "cmd-" + std::to_string(i) + "-" + std::to_string(attempt);
      Ack a = dev->on_command(mk(cid, order, slot));
      if (a.accepted) accepted_for_order++;
      int roll = std::rand() % 6;
      if (roll == 0) { run(60); hal.all_actuators_off(); dev.reset(new Device(hal, KEY, DEV, cfg)); dev->begin(); }   // power cut mid-spray
      else if (roll == 1) { run(1000); dev.reset(new Device(hal, KEY, DEV, cfg)); dev->begin(); }                        // clean reboot
      else run(1700);
      for (auto& res : dev->pending_results()) dev->confirm_result(res.command_id);
    }
    CHECK(accepted_for_order <= 1);
    accepted_total += accepted_for_order;
  }
  CHECK_EQ(hal.on_events, accepted_total);                          // valve opened exactly once per accepted command
  CHECK(hal.on_events <= ORDERS);
  CHECK(accepted_total > 5000);                                      // the run really exercised the happy path
}

TEST(power_loss_mid_spray_reports_uncertain_and_never_respray) {
  Rig r;
  CHECK(is(r.send(r.cmd("c1", "o1")), true, "ACCEPTED"));
  r.run(50);
  CHECK(r.hal.valve[0]);
  r.reboot();                                                       // power returns
  CHECK(!r.any_valve());                                            // valves forced closed at boot
  auto res = r.dev->pending_results();
  CHECK_EQ(res.size(), 1u);
  CHECK(res[0].outcome == Outcome::UNCERTAIN); CHECK_EQ(res[0].code, std::string("POWER_LOSS"));
  CHECK(is(r.send(r.cmd("c1", "o1")), false, "DUPLICATE_COMMAND"));
  CHECK(is(r.send(r.cmd("c9", "o1")), false, "DUPLICATE_ORDER"));
  CHECK(!r.any_valve());
}

TEST(door_opened_mid_spray_cuts_power_immediately) {
  Rig r;
  CHECK(is(r.send(r.cmd("c1", "o1", 1, 200)), true, "ACCEPTED"));
  r.run(50);
  r.hal.door = true;
  r.run(5);
  CHECK(!r.any_valve());
  auto res = r.dev->pending_results();
  CHECK_EQ(res.size(), 1u); CHECK(res[0].outcome == Outcome::UNCERTAIN); CHECK_EQ(res[0].code, std::string("ABORTED_DOOR"));
  CHECK_EQ(r.dev->slot(0).sale_sprays, 0u);                          // unconfirmed spray is not counted as sold
  r.hal.door = false;
  CHECK(is(r.send(r.cmd("c2", "o1")), false, "DUPLICATE_ORDER"));    // uncertain => review, not automatic retry
}

TEST(leak_mid_spray_latches_fault_until_technician_clears) {
  Rig r;
  r.send(r.cmd("c1", "o1"));
  r.run(40);
  r.hal.leak = true;
  r.run(10);
  CHECK(!r.any_valve());
  CHECK_EQ(r.dev->mode(), Mode::FAULT);
  r.hal.leak = false;
  CHECK(is(r.send(r.cmd("c2", "o2")), false, "CRITICAL_FAULT"));      // still latched although the probe is dry
  CHECK(!r.dev->clear_fault());                                       // not allowed outside maintenance
  CHECK(r.dev->enter_maintenance());
  r.hal.leak = true; CHECK(!r.dev->clear_fault()); r.hal.leak = false;
  CHECK(r.dev->clear_fault());
  CHECK(r.dev->fault().empty());
  r.run(1600);                                                        // cooldown after the aborted spray
  r.send(r.cmd("d1", "diag1", 1, 100, Action::DIAG_SPRAY)); r.run(1000);
  CHECK(r.dev->exit_maintenance());
  r.run(2000);
  CHECK(is(r.send(r.cmd("c3", "o3")), true, "ACCEPTED"));
}

TEST(actuator_watchdog_forces_off_when_tick_is_starved) {
  Rig r;
  r.send(r.cmd("c1", "o1"));
  r.hal.now_ms += 2000;                                              // firmware hung for 2 s: valve still on
  CHECK(r.hal.valve[0]);
  r.dev->tick();
  CHECK(!r.any_valve());
  CHECK_EQ(r.dev->fault(), std::string("ACTUATOR_OVERRUN"));
  CHECK_EQ(r.dev->mode(), Mode::FAULT);
  CHECK(r.dev->pending_results()[0].outcome == Outcome::UNCERTAIN);
}

TEST(measurement_outcomes_ok_failed_partial_sensor) {
  { Rig r; r.hal.clogged = true; r.send(r.cmd("c1", "o1")); r.run(1000);
    auto x = r.dev->pending_results()[0]; CHECK(x.outcome == Outcome::FAILED); CHECK_EQ(x.code, std::string("NO_FLOW"));
    CHECK_EQ(r.dev->slot(0).sale_sprays, 0u); }
  { Rig r; r.hal.mg_per_ms = 0.25; r.send(r.cmd("c1", "o1")); r.run(1000);                 // 30 mg of 90 expected
    auto x = r.dev->pending_results()[0]; CHECK(x.outcome == Outcome::UNCERTAIN); CHECK_EQ(x.code, std::string("PARTIAL_FLOW")); }
  { Rig r; r.send(r.cmd("c1", "o1")); r.run(200); r.hal.sensor_ok[0] = false; r.run(800);
    auto x = r.dev->pending_results()[0]; CHECK(x.outcome == Outcome::UNCERTAIN); CHECK_EQ(x.code, std::string("SENSOR_FAILURE")); }
  { Rig r; r.hal.clogged = true; r.send(r.cmd("c1", "o1")); r.run(1000);
    CHECK(is(r.send(r.cmd("c2", "o1")), false, "DUPLICATE_ORDER")); }                       // even a FAILED spray is never auto-retried
}

TEST(maintenance_diagnostic_rules) {
  Rig r;
  CHECK(!r.dev->exit_maintenance());
  CHECK(r.dev->enter_maintenance());
  CHECK_EQ(r.dev->mode(), Mode::MAINTENANCE);
  CHECK(!r.dev->exit_maintenance());                                 // no post-maintenance test yet
  CHECK(is(r.send(r.cmd("d1", "t1", 2, 120, Action::DIAG_SPRAY)), true, "ACCEPTED"));
  CHECK(!r.dev->enter_maintenance() || true);
  r.run(1000);
  CHECK_EQ(r.dev->slot(1).diag_sprays, 1u);
  CHECK_EQ(r.dev->slot(1).sale_sprays, 0u);                           // diagnostic sprays never count as sales
  CHECK(r.dev->pending_results()[0].diagnostic);
  CHECK(r.dev->exit_maintenance());
  CHECK_EQ(r.dev->mode(), Mode::IDLE);
}

TEST(cannot_enter_maintenance_while_spraying) {
  Rig r;
  r.send(r.cmd("c1", "o1"));
  CHECK(!r.dev->enter_maintenance());
  r.run(1000);
  CHECK(r.dev->enter_maintenance());
}

TEST(inventory_low_empty_leak_and_divergence) {
  { Rig r; r.hal.weight[0] = 1800; r.dev->install_bottle(0, 1800);                           // 20 sprays left
    CHECK(r.dev->slot(0).flags & FLAG_LOW); CHECK(!(r.dev->slot(0).flags & FLAG_EMPTY)); CHECK_EQ(r.dev->slot(0).remaining_sprays, 20); }
  { Rig r; r.hal.weight[0] = 250; r.dev->install_bottle(0, 250);
    CHECK(r.dev->slot(0).flags & FLAG_EMPTY); CHECK(is(r.send(r.cmd("c1", "o1", 1)), false, "SLOT_EMPTY")); }
  { Rig r; r.dev->install_bottle(1, 40000); r.run(11000);
    CHECK(!(r.dev->slot(1).flags & FLAG_LEAK));
    r.hal.weight[1] -= 1500; r.run(11000);                                                    // 1.5 g vanished with no spray
    CHECK(r.dev->slot(1).flags & FLAG_LEAK);
    bool alert = false; for (auto& e : r.dev->drain_events()) if (e.type == "SLOT_ALERT") alert = true; CHECK(alert); }
  { Rig r; r.dev->install_bottle(1, 40000); r.run(11000);                                      // normal sprays must not look like a leak
    for (int i = 0; i < 3; i++) { r.send(r.cmd("c" + std::to_string(i), "o" + std::to_string(i), 2)); r.run(2400); }
    r.run(11000);
    CHECK(!(r.dev->slot(1).flags & FLAG_LEAK)); CHECK(!(r.dev->slot(1).flags & FLAG_DIVERGENT)); CHECK_EQ(r.dev->slot(1).sale_sprays, 3u); }
  { Rig r; r.dev->install_bottle(2, 40000); r.hal.weight[2] = 30000; r.run(11000);
    CHECK(r.dev->slot(2).flags & FLAG_DIVERGENT); }
}

TEST(events_have_unique_ids_across_reboots_for_server_dedup) {
  Rig r;
  r.send(r.cmd("a", "o")); r.hal.door = true; r.send(r.cmd("b", "o2")); 
  auto e1 = r.dev->drain_events();
  r.reboot();
  auto e2 = r.dev->drain_events();
  CHECK(!e1.empty() && !e2.empty());
  for (auto& x : e1) for (auto& y : e2) CHECK(x.id != y.id);
  CHECK(r.dev->drain_events().empty());
}

TEST(offline_event_buffer_is_bounded) {
  Rig r;
  r.hal.door = true;
  for (int i = 0; i < 500; i++) r.send(r.cmd("c" + std::to_string(i), "o" + std::to_string(i)));
  CHECK(r.dev->drain_events().size() <= 100u);
}

TEST(ledger_fits_nvs_value_limit_and_survives_reboot) {
  Rig r; r.hal.max_value_bytes = 4000;                               // real ESP32 NVS limit for one string value
  auto uuid = [](const char* p, int i) { return std::string(p) + "-3f2b8c1e-9a47-4d52-b6e0-" + std::to_string(100000000000LL + i); };   // 36+ chars, like real backend ids
  int accepted = 0;
  for (int i = 0; i < 200; i++) {
    r.hal.weight[0] = 40000;
    Ack a = r.send(r.cmd(uuid("cmd", i), uuid("ord", i)));
    if (a.accepted) accepted++;
    r.run(2500);                                                     // spray + settle + cooldown
    for (auto& x : r.dev->pending_results()) r.dev->confirm_result(x.command_id);
  }
  CHECK_EQ(accepted, 200);                                           // storage never starts failing as the ledger grows
  r.reboot();
  CHECK(is(r.send(r.cmd(uuid("cmd", 199), uuid("ord", 199))), false, "DUPLICATE_COMMAND"));   // recent commands still remembered after reboot
  CHECK(is(r.send(r.cmd(uuid("cmd", 100), uuid("ord", 100))), false, "DUPLICATE_COMMAND"));   // inside the 128-entry window
}

TEST(estop_pressed_mid_spray_cuts_power_immediately) {
  Rig r;
  CHECK(is(r.send(r.cmd("c1", "o1", 1, 200)), true, "ACCEPTED"));
  r.run(50);
  r.hal.estop = true;
  r.run(5);
  CHECK(!r.any_valve());
  auto res = r.dev->pending_results();
  CHECK_EQ(res.size(), 1u); CHECK(res[0].outcome == Outcome::UNCERTAIN); CHECK_EQ(res[0].code, std::string("ABORTED_ESTOP"));
  CHECK_EQ(r.dev->slot(0).sale_sprays, 0u);
  r.hal.estop = false;
  CHECK(is(r.send(r.cmd("c2", "o1")), false, "DUPLICATE_ORDER"));    // uncertain => review, never an automatic second spray
}

TEST(events_stay_buffered_until_confirmed) {
  Rig r;
  auto ev = r.dev->pending_events();
  CHECK(!ev.empty());                                                // STARTUP at least
  CHECK_EQ(r.dev->pending_events().size(), ev.size());               // reading is non-destructive: a failed publish loses nothing
  r.dev->confirm_event(ev[0].id);
  CHECK_EQ(r.dev->pending_events().size(), ev.size() - 1);
}

TEST(uncalibrated_load_cell_blocks_spray_until_calibrated) {
  Rig r;
  r.hal.calibrated[0] = false;
  CHECK(is(r.send(r.cmd("c1", "o1")), false, "NOT_CALIBRATED"));
  CHECK(!r.any_valve());
  r.hal.calibrated[0] = true;
  CHECK(is(r.send(r.cmd("c3", "o3")), true, "ACCEPTED"));
  r.run(1000);
  CHECK_EQ(r.dev->slot(0).sale_sprays, 1u);
  Rig m;                                                             // diagnostic sprays need a calibrated scale too
  m.hal.calibrated[0] = false;
  CHECK(m.dev->enter_maintenance());
  CHECK(is(m.send(m.cmd("d1", "o4", 1, 120, Action::DIAG_SPRAY)), false, "NOT_CALIBRATED"));
  CHECK(!m.any_valve());
}
