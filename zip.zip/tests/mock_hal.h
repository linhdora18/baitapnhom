// Simulated kiosk hardware for host tests: time, GPIO, load cells with a simple physical model, flash storage.
#pragma once
#include <map>
#include <string>

#include "../core/hal.h"

struct MockHal : ss::Hal {
  uint64_t now_ms = 1000;
  int64_t unix_s = 1760000000;
  bool door = false, leak = false, estop = false, storage_fails = false;
  size_t max_value_bytes = 0;            // 0 = unlimited; ESP32 NVS strings hold at most ~4000 bytes
  bool calibrated[ss::MAX_SLOTS];
  bool sensor_ok[ss::MAX_SLOTS];
  bool valve[ss::MAX_SLOTS] = {false};
  int32_t weight[ss::MAX_SLOTS];
  double mg_per_ms = 0.75;               // 90 mg for a 120 ms dose
  bool clogged = false;                  // valve opens but nothing comes out
  std::map<std::string, std::string> flash;
  int off_calls = 0;

  MockHal() { for (int i = 0; i < ss::MAX_SLOTS; i++) { sensor_ok[i] = true; calibrated[i] = true; weight[i] = 40000; } }

  uint64_t millis() override { return now_ms; }
  int64_t unix_time() override { return unix_s; }
  void actuator(int s, bool on) override { valve[s] = on; }
  void all_actuators_off() override { for (bool& v : valve) v = false; off_calls++; }
  bool door_open() override { return door; }
  bool leak_detected() override { return leak; }
  bool estop_pressed() override { return estop; }
  bool read_weight_mg(int s, int32_t* mg) override { if (!sensor_ok[s]) return false; *mg = weight[s]; return true; }
  bool load_cell_calibrated(int s) override { return calibrated[s]; }
  bool storage_read(const char* k, std::string* v) override { auto it = flash.find(k); if (it == flash.end()) return false; *v = it->second; return true; }
  bool storage_write(const char* k, const std::string& v) override { if (storage_fails || (max_value_bytes && v.size() >= max_value_bytes)) return false; flash[k] = v; return true; }

  // advance simulated time by `ms` in 5 ms steps, running the physics and calling `step` (the firmware tick)
  template <class F> void run(uint32_t ms, F step) {
    for (uint32_t t = 0; t < ms; t += 5) {
      now_ms += 5; unix_s = 1760000000 + (int64_t)((now_ms - 1000) / 1000);
      for (int s = 0; s < ss::MAX_SLOTS; s++) if (valve[s] && !clogged) { acc_[s] += mg_per_ms * 5; int whole = (int)acc_[s]; weight[s] -= whole; acc_[s] -= whole; }
      step();
    }
  }
 private:
  double acc_[ss::MAX_SLOTS] = {0};
};
