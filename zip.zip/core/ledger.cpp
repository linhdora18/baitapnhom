#include "ledger.h"

#include <algorithm>
#include <cstdlib>

namespace ss {
const char* outcome_name(Outcome o) {
  switch (o) {
    case Outcome::IN_PROGRESS: return "IN_PROGRESS";
    case Outcome::OK: return "OK";
    case Outcome::FAILED: return "FAILED";
    default: return "UNCERTAIN";
  }
}

static Outcome outcome_from(const std::string& s) {
  if (s == "OK") return Outcome::OK;
  if (s == "FAILED") return Outcome::FAILED;
  if (s == "UNCERTAIN") return Outcome::UNCERTAIN;
  return Outcome::IN_PROGRESS;
}

static std::string key_for(uint32_t seq, size_t cap) { return "le" + std::to_string(seq % cap); }   // <= 15 chars (NVS key limit)

static std::string encode(const LedgerEntry& e) {   // seq|command|order|OUTCOME|code|delta|diag   (ids never contain '|', see valid_id)
  return std::to_string(e.seq) + "|" + e.command_id + "|" + e.order_id + "|" + outcome_name(e.outcome) + "|" + e.code + "|" +
         std::to_string(e.delta_mg) + "|" + (e.diagnostic ? "1" : "0");
}

static bool decode(const std::string& line, LedgerEntry* e) {
  std::vector<std::string> f;
  std::string cur;
  for (char ch : line) {
    if (ch == '|') { f.push_back(cur); cur.clear(); } else cur.push_back(ch);
  }
  f.push_back(cur);
  if (f.size() != 7) return false;                   // torn or foreign value: ignore
  e->seq = static_cast<uint32_t>(std::strtoul(f[0].c_str(), nullptr, 10));
  e->command_id = f[1]; e->order_id = f[2]; e->outcome = outcome_from(f[3]); e->code = f[4];
  e->delta_mg = std::atoi(f[5].c_str()); e->diagnostic = f[6] == "1";
  return e->seq > 0 && !e->command_id.empty();
}

void Ledger::load() {
  v_.clear();
  next_seq_ = 1;
  for (size_t i = 0; i < cap_; i++) {
    std::string blob;
    if (!hal_.storage_read(("le" + std::to_string(i)).c_str(), &blob)) continue;
    LedgerEntry e;
    if (decode(blob, &e)) v_.push_back(e);
  }
  std::sort(v_.begin(), v_.end(), [](const LedgerEntry& a, const LedgerEntry& b) { return a.seq < b.seq; });
  if (!v_.empty()) next_seq_ = v_.back().seq + 1;
}

bool Ledger::write_entry(const LedgerEntry& e) { return hal_.storage_write(key_for(e.seq, cap_).c_str(), encode(e)); }

const LedgerEntry* Ledger::find_command(const std::string& id) const {
  for (const auto& e : v_) if (e.command_id == id) return &e;
  return nullptr;
}

const LedgerEntry* Ledger::find_order(const std::string& id) const {
  for (const auto& e : v_) if (!e.diagnostic && e.order_id == id) return &e;
  return nullptr;
}

bool Ledger::add(const LedgerEntry& in) {
  LedgerEntry e = in;
  e.seq = next_seq_;
  if (!write_entry(e)) return false;                 // nothing changed: the caller must not spray
  ++next_seq_;
  v_.push_back(e);
  if (v_.size() > cap_) v_.erase(v_.begin());        // its storage slot was just overwritten by the new entry (same seq % cap)
  return true;
}

bool Ledger::update(const std::string& command_id, Outcome o, const std::string& code, int32_t delta_mg) {
  for (auto& e : v_) {
    if (e.command_id == command_id) {
      e.outcome = o; e.code = code; e.delta_mg = delta_mg;
      return write_entry(e);
    }
  }
  return false;
}
}  // namespace ss
