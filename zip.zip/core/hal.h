// Hardware abstraction layer. The safety logic in device.cpp only talks to this interface, so it can be
// unit-tested on a PC (tests/mock_hal.h) and run unchanged on the ESP32 (esp32/hal_esp32.cpp).
#pragma once
#include <cstdint>
#include <string>

namespace ss {
constexpr int MAX_SLOTS = 8;

class Hal {
 public:
  virtual ~Hal() = default;
  virtual uint64_t millis() = 0;                 // monotonic milliseconds since boot
  virtual int64_t unix_time() = 0;               // UTC seconds; 0 = clock NOT synchronised yet
  virtual void actuator(int slot, bool on) = 0;  // drive one slot's MOSFET channel
  virtual void all_actuators_off() = 0;
  virtual bool door_open() = 0;                  // reed switch
  virtual bool leak_detected() = 0;              // leak probe under the bottles
  virtual bool estop_pressed() = 0;              // hardware emergency stop (also cuts actuator power in hardware)
  virtual bool read_weight_mg(int slot, int32_t* mg) = 0;  // load cell; false = sensor failure / not settled
  virtual bool load_cell_calibrated(int /*slot*/) { return true; }   // false until the scale of this slot has been calibrated
  virtual bool storage_read(const char* key, std::string* value) = 0;   // non-volatile (NVS/flash)
  virtual bool storage_write(const char* key, const std::string& value) = 0;
};
}  // namespace ss
