// Signed dispensing command: canonical string, HMAC-SHA256 signature, hex helpers.
#pragma once
#include <cstdint>
#include <string>

namespace ss {
enum class Action { SPRAY, DIAG_SPRAY, UNKNOWN };

struct Command {
  std::string command_id, device_id, order_id, signature;   // signature = 64 hex chars
  int slot = -1;  // Protocol-facing slot number: 1..N (not a zero-based array index).
  Action action = Action::UNKNOWN;
  uint32_t dose_ms = 0;
  int64_t issued_at = 0, expires_at = 0;                    // UTC seconds
};

const char* action_name(Action a);
Action action_from_string(const std::string& s);
bool valid_id(const std::string& s);                        // [A-Za-z0-9._:-]{1,64}: no '|' or newline injection

// "v1|command_id|device_id|slot|ACTION|dose_ms|issued_at|expires_at|order_id" (same string the backend signs)
std::string canonical(const Command& c);
std::string sign(const std::string& key, const Command& c);           // lower-case hex
bool verify_signature(const std::string& key, const Command& c);      // constant-time

std::string hex_decode(const std::string& hex, bool* ok = nullptr);
}  // namespace ss
