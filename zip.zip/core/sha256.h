// Minimal SHA-256 / HMAC-SHA256 (host-testable). On ESP32 production builds mbedtls may replace it.
#pragma once
#include <cstddef>
#include <cstdint>
#include <string>

namespace ss {
void sha256(const uint8_t* data, size_t len, uint8_t out[32]);
void hmac_sha256(const uint8_t* key, size_t key_len, const uint8_t* msg, size_t msg_len, uint8_t out[32]);
std::string to_hex(const uint8_t* d, size_t n);
bool ct_equal(const uint8_t* a, const uint8_t* b, size_t n);   // constant-time compare
}  // namespace ss
