#include "protocol.h"
#include "sha256.h"

namespace ss {
const char* action_name(Action a) {
  switch (a) {
    case Action::SPRAY: return "SPRAY";
    case Action::DIAG_SPRAY: return "DIAG_SPRAY";
    default: return "UNKNOWN";
  }
}

Action action_from_string(const std::string& s) {
  if (s == "SPRAY") return Action::SPRAY;
  if (s == "DIAG_SPRAY") return Action::DIAG_SPRAY;
  return Action::UNKNOWN;
}

bool valid_id(const std::string& s) {
  if (s.empty() || s.size() > 64) return false;
  for (char ch : s) {
    bool ok = (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') || ch == '.' || ch == '_' || ch == ':' || ch == '-';
    if (!ok) return false;
  }
  return true;
}

std::string canonical(const Command& c) {
  return "v1|" + c.command_id + "|" + c.device_id + "|" + std::to_string(c.slot) + "|" + action_name(c.action) + "|" +
         std::to_string(c.dose_ms) + "|" + std::to_string(c.issued_at) + "|" + std::to_string(c.expires_at) + "|" + c.order_id;
}

std::string sign(const std::string& key, const Command& c) {
  std::string msg = canonical(c);
  uint8_t out[32];
  hmac_sha256(reinterpret_cast<const uint8_t*>(key.data()), key.size(), reinterpret_cast<const uint8_t*>(msg.data()), msg.size(), out);
  return to_hex(out, 32);
}

std::string hex_decode(const std::string& hex, bool* ok) {
  std::string out;
  bool good = hex.size() % 2 == 0;
  auto nib = [&](char ch) -> int {
    if (ch >= '0' && ch <= '9') return ch - '0';
    if (ch >= 'a' && ch <= 'f') return ch - 'a' + 10;
    if (ch >= 'A' && ch <= 'F') return ch - 'A' + 10;
    good = false;
    return 0;
  };
  for (size_t i = 0; good && i + 1 < hex.size(); i += 2) out.push_back(static_cast<char>(nib(hex[i]) << 4 | nib(hex[i + 1])));
  if (ok) *ok = good;
  return good ? out : std::string();
}

bool verify_signature(const std::string& key, const Command& c) {
  bool ok = false;
  std::string got = hex_decode(c.signature, &ok);
  if (!ok || got.size() != 32) return false;
  std::string want = hex_decode(sign(key, c));
  return ct_equal(reinterpret_cast<const uint8_t*>(got.data()), reinterpret_cast<const uint8_t*>(want.data()), 32);
}
}  // namespace ss
