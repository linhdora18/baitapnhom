#include "calibration.h"

#include <cmath>

namespace ss {
int32_t LoadCellCal::to_mg(int32_t raw) const { return static_cast<int32_t>(std::lround((raw - tare_raw) / counts_per_mg)); }

bool calibrate_load_cell(int32_t raw_empty, int32_t raw_known, int32_t known_mg, LoadCellCal* out) {
  if (known_mg <= 0 || raw_known == raw_empty) return false;
  out->tare_raw = raw_empty;
  out->counts_per_mg = static_cast<double>(raw_known - raw_empty) / known_mg;   // may be negative if wired inverted
  return true;
}

bool fit_dose_curve(const DosePoint* pts, size_t n, double* slope, double* offset) {
  if (n < 3) return false;                       // need >= 3 distinct doses to check linearity
  double sx = 0, sy = 0, sxx = 0, sxy = 0;
  for (size_t i = 0; i < n; i++) { sx += pts[i].dose_ms; sy += pts[i].mg_per_spray; sxx += pts[i].dose_ms * pts[i].dose_ms; sxy += pts[i].dose_ms * pts[i].mg_per_spray; }
  double den = n * sxx - sx * sx;
  if (std::fabs(den) < 1e-9) return false;
  double m = (n * sxy - sx * sy) / den, b = (sy - m * sx) / n;     // mg = m*dose + b
  if (m <= 0) return false;
  *slope = m;
  *offset = -b / m;
  return true;
}

uint32_t dose_for_target(double slope, double offset, double target_mg) {
  double ms = target_mg / slope + offset;
  return ms < 1 ? 1u : static_cast<uint32_t>(std::lround(ms));
}

double coefficient_of_variation(const double* v, size_t n) {
  if (n < 2) return 100.0;
  double mean = 0;
  for (size_t i = 0; i < n; i++) mean += v[i];
  mean /= n;
  if (mean <= 0) return 100.0;
  double ss = 0;
  for (size_t i = 0; i < n; i++) ss += (v[i] - mean) * (v[i] - mean);
  return std::sqrt(ss / (n - 1)) / mean * 100.0;
}
}  // namespace ss
