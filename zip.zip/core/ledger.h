// Persistent record of every accepted command. Stored as a ring of small NVS values (one key per entry, "le0".."le127"):
// each write is a few dozen bytes (NVS strings are limited to ~4000 bytes) and each command costs one small flash write
// instead of rewriting the whole ledger. It is what makes "one paid order -> at most one spray"
// hold across replays, duplicate MQTT deliveries AND power loss in the middle of a spray.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

#include "hal.h"

namespace ss {
enum class Outcome { IN_PROGRESS, OK, FAILED, UNCERTAIN };
const char* outcome_name(Outcome o);

struct LedgerEntry {
  std::string command_id, order_id, code;
  Outcome outcome = Outcome::IN_PROGRESS;
  int32_t delta_mg = 0;
  bool diagnostic = false;
  uint32_t seq = 0;                                // monotonic insertion number; decides the storage slot (seq % capacity)
};

class Ledger {
 public:
  // capacity must exceed (max command window / cooldown) so a live command can never be evicted: 120 s / 1.5 s = 80.
  explicit Ledger(Hal& hal, size_t capacity = 128) : hal_(hal), cap_(capacity) {}
  void load();                                     // read from non-volatile storage
  const LedgerEntry* find_command(const std::string& id) const;
  const LedgerEntry* find_order(const std::string& id) const;   // customer sprays only
  bool add(const LedgerEntry& e);                  // persists BEFORE the caller may actuate; false => do not spray
  bool update(const std::string& command_id, Outcome o, const std::string& code, int32_t delta_mg);
  const std::vector<LedgerEntry>& entries() const { return v_; }

 private:
  bool write_entry(const LedgerEntry& e);
  Hal& hal_;
  size_t cap_;
  std::vector<LedgerEntry> v_;
  uint32_t next_seq_ = 1;
};
}  // namespace ss
