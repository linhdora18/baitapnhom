// Calibration maths (pure functions, no hardware): load cell scale and spray dose curve.
#pragma once
#include <cstddef>
#include <cstdint>

namespace ss {
// ---- load cell: weight_mg = (raw - tare_raw) / counts_per_mg
struct LoadCellCal {
  int32_t tare_raw = 0;
  double counts_per_mg = 1.0;
  int32_t to_mg(int32_t raw) const;
};
// Two-point calibration: tare reading with empty platform, then a reference mass of known weight.
bool calibrate_load_cell(int32_t raw_empty, int32_t raw_known, int32_t known_mg, LoadCellCal* out);

// ---- spray dose: mass sprayed vs actuator open time. Linear model  mg = slope * (dose_ms - offset_ms)
// offset_ms is the valve/pump dead time before liquid actually leaves the nozzle.
struct DosePoint { double dose_ms; double mg_per_spray; };   // mg_per_spray = total mass / number of sprays
bool fit_dose_curve(const DosePoint* pts, size_t n, double* slope_mg_per_ms, double* offset_ms);
uint32_t dose_for_target(double slope_mg_per_ms, double offset_ms, double target_mg);

// Repeatability: coefficient of variation (%) of per-spray masses. Accept a calibration when <= 5 %.
double coefficient_of_variation(const double* masses_mg, size_t n);
}  // namespace ss
