#include "device.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>

namespace ss {
const char* mode_name(Mode m) {
  switch (m) {
    case Mode::IDLE: return "IDLE";
    case Mode::DISPENSING: return "DISPENSING";
    case Mode::MAINTENANCE: return "MAINTENANCE";
    default: return "FAULT";
  }
}

Device::Device(Hal& hal, const std::string& key, const std::string& device_id, const Config& cfg)
    : hal_(hal), key_(key), id_(device_id), cfg_(cfg), ledger_(hal) {}

Mode Device::mode() const {
  if (active_) return Mode::DISPENSING;
  if (maint_) return Mode::MAINTENANCE;
  if (!fault_.empty()) return Mode::FAULT;
  return Mode::IDLE;
}

void Device::event(const char* type, const std::string& detail) {
  if (events_.size() >= 100) events_.erase(events_.begin());       // bounded offline buffer, oldest dropped
  ++seq_;
  events_.push_back({seq_, id_ + "-" + std::to_string(boot_count_) + "-" + std::to_string(seq_), type, detail});
}

std::vector<Event> Device::drain_events() { std::vector<Event> e; e.swap(events_); return e; }

void Device::confirm_event(const std::string& id) {
  events_.erase(std::remove_if(events_.begin(), events_.end(), [&](const Event& e) { return e.id == id; }), events_.end());
}

void Device::latch_fault(const std::string& code) {
  if (fault_.empty()) event("FAULT", code);
  fault_ = code;
}

void Device::begin() {
  hal_.all_actuators_off();                       // never start with a valve open
  std::string bc;
  boot_count_ = hal_.storage_read("bootcount", &bc) ? static_cast<uint32_t>(std::strtoul(bc.c_str(), nullptr, 10)) + 1 : 1;
  hal_.storage_write("bootcount", std::to_string(boot_count_));
  ledger_.load();
  // A command that was IN_PROGRESS when power failed may or may not have sprayed: report UNCERTAIN, never re-spray.
  for (const auto& e : ledger_.entries()) {
    if (e.outcome != Outcome::IN_PROGRESS) continue;
    ledger_.update(e.command_id, Outcome::UNCERTAIN, "POWER_LOSS", 0);
    Result r; r.command_id = e.command_id; r.order_id = e.order_id; r.outcome = Outcome::UNCERTAIN; r.code = "POWER_LOSS"; r.diagnostic = e.diagnostic;
    results_.push_back(r);
  }
  event("STARTUP", "boot " + std::to_string(boot_count_));
  last_sample_ms_ = hal_.millis();
  sample_inventory();
}

Ack Device::reject(const Command& c, const char* code) {
  event("COMMAND_REJECTED", c.command_id + ":" + code);
  return {c.command_id, false, code};
}

Ack Device::on_command(const Command& c) {
  // 0. syntax
  if (!valid_id(c.command_id) || !valid_id(c.device_id) || !valid_id(c.order_id) || c.action == Action::UNKNOWN) return reject(c, "BAD_FORMAT");
  // 1. addressing and authenticity (cheap checks that need no state first)
  if (c.device_id != id_) return reject(c, "WRONG_DEVICE");
  if (!verify_signature(key_, c)) return reject(c, "BAD_SIGNATURE");
  // 2. freshness
  int64_t now = hal_.unix_time();
  if (now <= 0) return reject(c, "TIME_NOT_SYNCED");
  if (c.expires_at <= c.issued_at || c.expires_at - c.issued_at > cfg_.max_window_s) return reject(c, "BAD_WINDOW");
  if (now > c.expires_at) return reject(c, "EXPIRED");
  if (c.issued_at > now + cfg_.skew_s) return reject(c, "FROM_FUTURE");
  // 3. replay / idempotency: same command or same paid order can never spray twice
  if (ledger_.find_command(c.command_id)) return reject(c, "DUPLICATE_COMMAND");
  if (c.action == Action::SPRAY && ledger_.find_order(c.order_id)) return reject(c, "DUPLICATE_ORDER");
  // 4. device state and interlocks
  if (active_) return reject(c, "BUSY");
  if (hal_.estop_pressed()) return reject(c, "ESTOP");
  if (hal_.leak_detected()) return reject(c, "LEAK_DETECTED");
  if (hal_.door_open()) return reject(c, "DOOR_OPEN");
  if (c.action == Action::SPRAY) {
    if (maint_) return reject(c, "MAINTENANCE_MODE");
    if (!fault_.empty()) return reject(c, "CRITICAL_FAULT");
  } else if (!maint_) {
    return reject(c, "REQUIRES_MAINTENANCE_MODE");
  }
  // 5. slot and dose
  // Protocol slot numbers are human-facing 1..N. Convert once to the zero-based HAL array index.
  if (c.slot < 1 || c.slot > cfg_.slot_count) return reject(c, "BAD_SLOT");
  const int idx = c.slot - 1;
  const SlotConfig& sc = cfg_.slots[idx];
  if (!sc.enabled) return reject(c, "SLOT_DISABLED");
  if (!hal_.load_cell_calibrated(idx)) return reject(c, "NOT_CALIBRATED");   // weight readings are meaningless before the scale is calibrated
  if (c.dose_ms == 0 || c.dose_ms > sc.max_dose_ms) return reject(c, "DOSE_OUT_OF_RANGE");
  if (had_spray_ && hal_.millis() - last_end_ms_ < cfg_.cooldown_ms) return reject(c, "COOLDOWN");
  int32_t w = 0;
  if (!hal_.read_weight_mg(idx, &w)) { slots_[idx].flags |= FLAG_SENSOR; return reject(c, "SENSOR_FAILURE"); }
  if (liquid_mg(idx, w) < std::max(sc.min_safe_liquid_mg, sc.mg_per_spray)) return reject(c, "SLOT_EMPTY");

  // 6. commit: persist BEFORE actuating. If storage fails we refuse to spray (cannot guarantee idempotency).
  LedgerEntry e; e.command_id = c.command_id; e.order_id = c.order_id; e.outcome = Outcome::IN_PROGRESS;
  e.diagnostic = c.action == Action::DIAG_SPRAY;
  if (!ledger_.add(e)) return reject(c, "STORAGE_FAILURE");
  cur_ = Active(); cur_.cmd = c; cur_.baseline_mg = w; cur_.start_ms = hal_.millis();
  active_ = true;
  actuations_[idx]++;
  hal_.actuator(idx, true);
  return {c.command_id, true, "ACCEPTED"};
}

void Device::finish(Outcome o, const std::string& code, int32_t delta_mg) {
  const Command& c = cur_.cmd;
  const int idx = c.slot - 1;  // Command.slot is protocol-facing (1-based).
  uint32_t executed = static_cast<uint32_t>((cur_.stop_ms ? cur_.stop_ms : hal_.millis()) - cur_.start_ms);
  ledger_.update(c.command_id, o, code, delta_mg);
  Result r; r.command_id = c.command_id; r.order_id = c.order_id; r.outcome = o; r.code = code; r.delta_mg = delta_mg;
  r.executed_ms = executed; r.diagnostic = c.action == Action::DIAG_SPRAY;
  results_.push_back(r);
  if (o == Outcome::OK) {
    if (r.diagnostic) { slots_[idx].diag_sprays++; diag_ok_ = true; } else slots_[idx].sale_sprays++;   // sale stock only on confirmed spray
    sprays_since_install_[idx]++;
  }
  if (o != Outcome::OK) event("DISPENSE_PROBLEM", c.command_id + ":" + outcome_name(o) + ":" + code);
  active_ = false;
  had_spray_ = true;
  last_end_ms_ = hal_.millis();
}

void Device::tick() {
  uint64_t now = hal_.millis();
  if (active_) {
    if (!cur_.off) {
      uint64_t elapsed = now - cur_.start_ms;
      const int idx = cur_.cmd.slot - 1;
      const SlotConfig& sc = cfg_.slots[idx];
      const char* abort_code = hal_.estop_pressed() ? "ABORTED_ESTOP" : hal_.leak_detected() ? "ABORTED_LEAK" : hal_.door_open() ? "ABORTED_DOOR" : nullptr;
      if (abort_code) {                                     // interlock tripped mid-spray: cut power first, then report
        hal_.all_actuators_off(); cur_.off = true; cur_.stop_ms = now;
        if (hal_.leak_detected()) latch_fault("LEAK");
        finish(Outcome::UNCERTAIN, abort_code, 0);          // part of the dose may have left the nozzle
        return;
      }
      if (elapsed > static_cast<uint64_t>(sc.max_dose_ms) + cfg_.overrun_margin_ms) {   // watchdog: tick() was starved
        hal_.all_actuators_off(); cur_.off = true; cur_.stop_ms = now;
        latch_fault("ACTUATOR_OVERRUN");
        finish(Outcome::UNCERTAIN, "ACTUATOR_OVERRUN", 0);
        return;
      }
      if (elapsed >= cur_.cmd.dose_ms) { hal_.actuator(idx, false); cur_.off = true; cur_.stop_ms = now; }
      return;
    }
    if (now - cur_.stop_ms < cfg_.settle_ms) return;
    // measure what actually left the bottle
    const int idx = cur_.cmd.slot - 1;
    const SlotConfig& sc = cfg_.slots[idx];
    int32_t after = 0;
    if (!hal_.read_weight_mg(idx, &after)) { slots_[idx].flags |= FLAG_SENSOR; finish(Outcome::UNCERTAIN, "SENSOR_FAILURE", 0); return; }
    int32_t delta = cur_.baseline_mg - after;
    double expected = static_cast<double>(sc.mg_per_spray) * cur_.cmd.dose_ms / sc.dose_ms;
    if (delta >= 0.5 * expected) finish(Outcome::OK, "OK", delta);
    else if (delta <= 0.1 * expected) finish(Outcome::FAILED, "NO_FLOW", delta);          // nothing came out: refund candidate
    else finish(Outcome::UNCERTAIN, "PARTIAL_FLOW", delta);                               // ambiguous: operator review, no auto-retry
    return;
  }
  if (hal_.leak_detected()) latch_fault("LEAK");
  if (now - last_sample_ms_ >= cfg_.sample_interval_ms) { last_sample_ms_ = now; sample_inventory(); }
}

void Device::sample_inventory() {
  for (int i = 0; i < cfg_.slot_count; i++) {
    const SlotConfig& sc = cfg_.slots[i];
    SlotStatus& s = slots_[i];
    int32_t w = 0;
    if (!hal_.load_cell_calibrated(i) || !hal_.read_weight_mg(i, &w)) {
      if (!(s.flags & FLAG_SENSOR)) event("SENSOR_ERROR", "slot " + std::to_string(i));
      s.flags |= FLAG_SENSOR;
      continue;
    }
    s.flags &= ~FLAG_SENSOR;
    uint8_t before = s.flags;
    int32_t liquid = std::max<int32_t>(0, liquid_mg(i, w));
    s.remaining_sprays = sc.mg_per_spray > 0 ? liquid / sc.mg_per_spray : 0;
    // low / empty
    if (liquid < std::max(sc.min_safe_liquid_mg, sc.mg_per_spray)) s.flags |= FLAG_EMPTY; else s.flags &= ~FLAG_EMPTY;
    if (s.remaining_sprays <= sc.low_sprays) s.flags |= FLAG_LOW; else s.flags &= ~FLAG_LOW;
    // leak: weight lost since the previous sample beyond what the sprays in between explain
    if (s.weight_mg >= 0) {
      double lost = s.weight_mg - w;
      double explained = (actuations_[i] - actuations_at_sample_[i]) * static_cast<double>(sc.mg_per_spray) * 1.5;   // +50 % margin
      if (lost - explained > cfg_.leak_tolerance_mg) s.flags |= FLAG_LEAK;
    }
    // divergence between the dose-counter estimate and the load cell, relative to the usable liquid
    if (install_mg_[i] > 0) {
      double est = install_mg_[i] - static_cast<double>(sprays_since_install_[i]) * sc.mg_per_spray;
      double span = std::max(1, install_mg_[i] - sc.empty_mg);
      if (std::fabs(est - w) / span * 100.0 > cfg_.divergence_pct) s.flags |= FLAG_DIVERGENT; else s.flags &= ~FLAG_DIVERGENT;
    }
    s.weight_mg = w;
    actuations_at_sample_[i] = actuations_[i];
    for (uint8_t f : {FLAG_LOW, FLAG_EMPTY, FLAG_LEAK, FLAG_DIVERGENT})
      if ((s.flags & f) && !(before & f)) event("SLOT_ALERT", "slot " + std::to_string(i) + " flag " + std::to_string(f));
  }
}

bool Device::enter_maintenance() {
  if (active_) return false;
  maint_ = true; diag_ok_ = false;
  event("MAINTENANCE_ENTER", "");
  return true;
}

bool Device::exit_maintenance() {
  if (!maint_ || !diag_ok_ || !fault_.empty()) return false;       // post-maintenance test is mandatory
  maint_ = false;
  event("MAINTENANCE_EXIT", "");
  return true;
}

bool Device::clear_fault() {
  if (!maint_ || hal_.leak_detected()) return false;
  fault_.clear();
  for (int i = 0; i < cfg_.slot_count; i++) slots_[i].flags &= ~FLAG_LEAK;
  event("FAULT_CLEARED", "");
  return true;
}

void Device::install_bottle(int slot, int32_t measured_mg) {
  if (slot < 0 || slot >= cfg_.slot_count) return;
  install_mg_[slot] = measured_mg;
  sprays_since_install_[slot] = 0;
  slots_[slot].sale_sprays = 0; slots_[slot].diag_sprays = 0;
  slots_[slot].weight_mg = measured_mg;
  slots_[slot].flags = 0;
  actuations_at_sample_[slot] = actuations_[slot];
  event("BOTTLE_INSTALLED", "slot " + std::to_string(slot) + " " + std::to_string(measured_mg) + "mg");
  sample_inventory();
}

void Device::confirm_result(const std::string& command_id) {
  results_.erase(std::remove_if(results_.begin(), results_.end(), [&](const Result& r) { return r.command_id == command_id; }), results_.end());
}
}  // namespace ss
