// Kiosk controller safety core: validates signed commands, runs exactly one calibrated spray,
// enforces door / stock / timeout / leak interlocks, and keeps inventory estimates.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

#include "hal.h"
#include "ledger.h"
#include "protocol.h"

namespace ss {
enum class Mode { IDLE, DISPENSING, MAINTENANCE, FAULT };
const char* mode_name(Mode m);

struct SlotConfig {
  bool enabled = true;
  uint32_t dose_ms = 120;        // calibrated nominal dose
  uint32_t max_dose_ms = 250;    // HARD limit enforced by the device whatever the cloud asks for
  int32_t mg_per_spray = 90;     // calibrated mass for dose_ms (see calibration.h)
  int32_t empty_mg = 0;          // load-cell reading with an empty bottle installed
  int32_t min_safe_liquid_mg = 300;   // below this much liquid the slot is "empty"
  int32_t low_sprays = 20;       // raise LOW when fewer sprays remain
};

struct Config {
  int slot_count = 5;
  uint32_t cooldown_ms = 1500;          // minimum gap between sprays on the machine
  uint32_t settle_ms = 600;             // wait for the scale to settle before measuring
  uint32_t overrun_margin_ms = 50;      // watchdog: actuator may never stay on longer than max_dose + margin
  uint32_t sample_interval_ms = 10000;  // inventory / leak sampling period while idle
  int64_t max_window_s = 120;           // longest accepted command lifetime
  int64_t skew_s = 5;                   // tolerated clock skew
  double leak_tolerance_mg = 400;       // unexplained loss between samples that triggers LEAK_SUSPECTED
  double divergence_pct = 15;           // estimate-vs-sensor mismatch that triggers ABNORMAL_CONSUMPTION
  SlotConfig slots[MAX_SLOTS];
};

struct Ack { std::string command_id; bool accepted; std::string code; };

struct Result {
  std::string command_id, order_id, code;
  Outcome outcome = Outcome::UNCERTAIN;
  int32_t delta_mg = 0;
  uint32_t executed_ms = 0;
  bool diagnostic = false;
};

enum SlotFlag : uint8_t { FLAG_LOW = 1, FLAG_EMPTY = 2, FLAG_LEAK = 4, FLAG_DIVERGENT = 8, FLAG_SENSOR = 16 };

struct SlotStatus {
  int32_t weight_mg = -1;            // last good reading (-1 = none)
  int32_t remaining_sprays = -1;
  uint32_t sale_sprays = 0, diag_sprays = 0;   // diagnostic sprays are counted separately from customer sales
  uint8_t flags = 0;
};

struct Event { uint32_t seq; std::string id, type, detail; };   // id = device-bootcount-seq (idempotent on the server)

class Device {
 public:
  Device(Hal& hal, const std::string& key, const std::string& device_id, const Config& cfg);

  void begin();                                // call once at boot, after the HAL is ready
  Ack on_command(const Command& c);            // validates; starts the spray when accepted
  void tick();                                 // call every <= 10 ms

  // ---- technician / inventory actions (authenticated by the local layer before calling) ----
  bool enter_maintenance();
  bool exit_maintenance();                     // only after a successful diagnostic spray and no active fault
  bool clear_fault();                          // only in maintenance, and only when the leak probe is dry
  void install_bottle(int slot, int32_t measured_mg);   // Internal zero-based index: 0..slot_count-1.   // inventory staff: new bottle, resets counters

  Mode mode() const;
  const SlotStatus& slot(int i) const { return slots_[i]; }  // Internal zero-based index: 0..slot_count-1.
  const std::string& fault() const { return fault_; }
  bool results_pending() const { return !results_.empty(); }
  std::vector<Result> pending_results() const { return results_; }   // re-sent until confirmed
  void confirm_result(const std::string& command_id);
  std::vector<Event> drain_events();            // removes everything (tests / simple callers)
  std::vector<Event> pending_events() const { return events_; }   // non-destructive: publish, then confirm_event() each one that was sent
  void confirm_event(const std::string& id);

 private:
  struct Active { Command cmd; uint64_t start_ms = 0, stop_ms = 0; int32_t baseline_mg = 0; bool off = false; };
  Ack reject(const Command& c, const char* code);
  void finish(Outcome o, const std::string& code, int32_t delta_mg);
  void latch_fault(const std::string& code);
  void sample_inventory();
  void event(const char* type, const std::string& detail);
  int32_t liquid_mg(int slot, int32_t weight) const { return weight - cfg_.slots[slot].empty_mg; }

  Hal& hal_;
  std::string key_, id_;
  Config cfg_;
  Ledger ledger_;
  SlotStatus slots_[MAX_SLOTS];
  uint32_t actuations_[MAX_SLOTS] = {0}, actuations_at_sample_[MAX_SLOTS] = {0};
  int32_t install_mg_[MAX_SLOTS] = {0};
  uint32_t sprays_since_install_[MAX_SLOTS] = {0};
  bool active_ = false, maint_ = false, diag_ok_ = false;
  Active cur_;
  uint64_t last_end_ms_ = 0, last_sample_ms_ = 0;
  bool had_spray_ = false;
  std::string fault_;
  std::vector<Result> results_;
  std::vector<Event> events_;
  uint32_t seq_ = 0, boot_count_ = 0;
};
}  // namespace ss
